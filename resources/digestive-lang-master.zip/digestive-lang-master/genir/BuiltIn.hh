#pragma once

/**
 * Forward declarations.
 */
class TACFun;
class PlnStmt;

namespace Generate {
    void pln(TACFun* fun, PlnStmt* stmt);
}
