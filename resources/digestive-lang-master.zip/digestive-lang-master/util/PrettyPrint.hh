//
// Created by wax on 12/14/16.
//

#ifndef DIG_PRETTYPRINT_H
#define DIG_PRETTYPRINT_H

#include <iostream>

const size_t INDENT_LENGTH = 4;

void printIndent(size_t indent);

#endif //DIG_PRETTYPRINT_H
