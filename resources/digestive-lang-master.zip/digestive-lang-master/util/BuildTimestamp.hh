#pragma once

#include <string>


/**
 * String containing date and time the compiler executable
 * was built.
 */
std::string buildTimestamp();
