#include "UnaryExpr.hh"
#include "ir/TACOp.hh"


UnaryExpr::UnaryExpr(Operator* op, Expr* expr) : op{op}, expr{expr} { }


UnaryExpr::~UnaryExpr() {
    delete op;
    delete expr;
}


void UnaryExpr::analyze(Scope* scope) {
    expr->analyze(scope);

    /**
     * FIXME will not work as expected for natural numbers and to be implemented product types.
     */
    type = expr->type;
}


bool UnaryExpr::equals(const Node& other) const {
    const UnaryExpr* o { dynamic_cast<const UnaryExpr*>(&other) };
    if (o == nullptr) return false;
    return *o->op == *op && *o->expr == *expr;
}


void UnaryExpr::dump(size_t indent) {
    std::cout << "(";

    op->dump(indent + 1);
    expr->dump(indent + 1);

    std::cout << ")";
}


TACOp UnaryExpr::generate(TACFun* env) {
    assert(false);
    return TACOp();
}
