#include "Operator.hh"

#include <map>
#include <assert.h>

#include "util/PrettyPrint.hh"

/**
 * Forward declarations.
 */
OperatorSymbol symbolFromString(std::string s);
const std::string symbolToString(OperatorSymbol symbol);
int precedenceOf(OperatorSymbol symbol);


Operator::Operator() : symbol{OperatorSymbol::NOT_AN_OPERATOR},
                       precedence{precedenceOf(symbol)} { }


Operator::Operator(std::string s) : symbol{symbolFromString(s)},
                                    precedence{precedenceOf(symbol)} { }


Operator::Operator(OperatorSymbol symbol) : symbol{symbol},
                                            precedence{precedenceOf(symbol)} { }


void Operator::dump(size_t indent) {
    std::cout << symbolToString(this->symbol);
}


const std::map<std::string, OperatorSymbol> stringToSymbol
        {
                {"+", OperatorSymbol::PLUS},
                {"-", OperatorSymbol::MINUS},
                {"*", OperatorSymbol::MUL},
                {"/", OperatorSymbol::DIV},

		{"=", OperatorSymbol::ASSIGN},

                {"==", OperatorSymbol::EQ},
                {"!=", OperatorSymbol::NOTEQ},
                {"<=", OperatorSymbol::LESSEQ},
                {">=", OperatorSymbol::GREATEREQ},
                {"<", OperatorSymbol::LESS},
                {">", OperatorSymbol::GREATER},
		
		{".", OperatorSymbol::DOT}
        };


bool Operator::isOperator(std::string s) {
    return stringToSymbol.find(s) != stringToSymbol.end();
}


bool Operator::equals(const Node &other) const {
    const Operator* o { dynamic_cast<const Operator*>(&other) };
    if (o == nullptr) return false;

    return o->symbol == symbol;
}


bool Operator::isBinary() {
    switch(symbol) {
        case OperatorSymbol::MINUS:
            return true;
        default:
            return !isUnary();
    }
}


bool Operator::isUnary() {
    switch(symbol) {
        case OperatorSymbol::MINUS:
            return true;
        default:
            return false;
    }
}


bool Operator::isRightAssociative() {
    if (symbol == OperatorSymbol::ASSIGN) return true;
    return false;
}


bool Operator::isLeftAssociative() {
    return !isRightAssociative();
}


OperatorSymbol symbolFromString(std::string s) {
    return stringToSymbol.at(s);
}


const std::string symbolToString(OperatorSymbol symbol) {
    switch(symbol) {
    case OperatorSymbol::PLUS: return "+";
    case OperatorSymbol::MINUS: return "-";
    case OperatorSymbol::MUL: return "*";
    case OperatorSymbol::DIV: return "/";

    case OperatorSymbol::ASSIGN: return "=";
	
    case OperatorSymbol::EQ: return "==";
    case OperatorSymbol::NOTEQ: return "!=";
    case OperatorSymbol::LESSEQ: return "<=";
    case OperatorSymbol::GREATEREQ: return ">=";
    case OperatorSymbol::LESS: return "<";
    case OperatorSymbol::GREATER: return ">";
	
    case OperatorSymbol::DOT: return ".";
	
    case OperatorSymbol::NOT_AN_OPERATOR: return "NOT_AN_OPERATOR";
    }

    assert(false);
}


int precedenceOf(OperatorSymbol symbol) {
    switch (symbol) {
    case OperatorSymbol::DOT:
	return 1;
    case OperatorSymbol::ASSIGN:
	return 2;

    case OperatorSymbol::EQ:
    case OperatorSymbol::NOTEQ:
    case OperatorSymbol::LESSEQ:
    case OperatorSymbol::GREATEREQ:
    case OperatorSymbol::LESS:
    case OperatorSymbol::GREATER:
	return 5;
	
    case OperatorSymbol::PLUS:
    case OperatorSymbol::MINUS:
	return 10;
	
    case OperatorSymbol::MUL:
    case OperatorSymbol::DIV:
	return 20;
			
    case OperatorSymbol::NOT_AN_OPERATOR:
	return -1;
    }

    assert(false);
}
