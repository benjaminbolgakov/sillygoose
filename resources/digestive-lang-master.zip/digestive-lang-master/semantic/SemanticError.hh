#pragma once

#include <string>

[[noreturn]] void semanticError(std::string message);
