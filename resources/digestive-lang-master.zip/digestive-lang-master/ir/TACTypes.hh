#pragma once

#include "TACType.hh"

TACType TACTYPE_TUPLE = TACType(TACKind::PTR, sizeof(void*));
