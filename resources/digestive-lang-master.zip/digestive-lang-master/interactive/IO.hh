//
// Created by wax on 1/25/17.
//

#ifndef DIG_IO_H
#define DIG_IO_H


#include <fstream>

namespace IO {
    extern std::ifstream in;

    bool init();
}
#endif //DIG_IO_H
