#pragma once

#include "jit/Jit.hh"

namespace Interactive {
    void start(Jit* jit);
    void loop(Jit* jit);
}
